
__________________________________________________________
Secure Coding Practices
__________________________________________________________

Q1. Which All Other Operators Will Lead To Overflow/Underflow and Why?




Questions
__________________________________________________________

	Write Following sum Function In C/C++/Java
		// Return Valid Sum
		// or Print Cann't Calculate Sum For Given a and b

		int sum(int a, int b) {
			
		}

	Write Following sum Function In C/C++/Java
	
	int sum(int a, int b) {
		return a + b;
	}


	int sum(int a,int b) {
		int c = a + b;

		// Is This Condition Going To Work?
		// It's Always False, Because of Closure Law
		if ( c > Integer.max_value) { 
	  		System.out.println(""arguments out of range"");
		}
			return c;
	}


	private static int sum(int a,int b) throws Exception {
	  try {
     		int c= a + b;

		    Integer.sum(a, b); // Not Efficient Code

		// ALWAYS TRUE - CLOSURE LAW
		if(c<=Integer.MAX_VALUE && c>= Integer.MIN_VALUE) { 
	     return c;
    }else { // DEAD CODE - NEVER GOING TO HIT
     throw new Exception(""Can't Calculate"");
    }
  }catch(Exception e) {
   throw e;
  }  
 }


// ALWAYS TRUE - CLOSURE LAW
if(a<=Integer.MAX_VALUE && b<=Integer.MAX_VALUE) 


int sum(int a, int b){
	long c=0l;
	
	try {
		c = a + b; 
	} catch(Exception e) {
		System.out.println(""Print Cannot Calculate Sum For Given a and b"");
	}
	
	return (int)c; // TYPE MESS IS HERE
}

private static int add(int x,int y)
{
   double z=x+y;
	return (int)z; // TYPE MESS IS HERE
}

if (a>0 && b>0)
{
  long c = a +b;
  
  if a+b > INT_MAX; // ALWAYS FALSE - CLOSURE LAW
      System.out.println(""cannot print valid sum""); 
  else
     System.out.println(c);      
}


int sum(int a, int b) {
	int result = a+b;
	if(result>0){ // NOT COMPLETE CODE
        return result;
	} else {
		System.out.println(""Calulation not possible of given number"");
	}
}


public int sum(int a, int b) {

	// BAD CONDITION - CLOSURE LAW VIOLATION
	if(a >= Integer.maxValue || b>=Integer.maxValue){ 
		throw RuntimeException("Value is out of range")
	}
	return a+b;
	}
}

__________________________________________________________
SECURITY DESIGN PRINCIPLE
	NEVER MESS WITH DATA TYPE DEFINITION
__________________________________________________________

How To Add Your Code In Google Sheet
__________________________________________________________
	1. Select Cell In Front of Your Name
	2. Put Cursor in Fx Text Box 
	3. Paste Your Solution in Fx Text Box


Natural Number is Data Type?
__________________________________________________________
from Mayank Gupta to Everyone:    12:13  PM
True
from iroti.mahajan to Everyone:    12:13  PM
True

from Sheetal Sharma to Everyone:    12:13  PM
False. Because data can be anything other than natural number.

from Amruta Ghodke to Everyone:    12:14  PM
false ,,because does this cover string char ? natural number is data type related to number not all data types

from Deepak Sonawane to Everyone:    12:14  PM

True- Natural Numbers are from 0 to 9 and each data type in bytecode can take values of 0 or 1 which are also natural numbers 

from Nehal Jyotish Ghoda to Everyone:    12:15  PM
True. as natural number can be 0,1,2,3.....

from Ketan to Everyone:    12:15  PM
F - Number is data type...natural numbers are subset of it

from Avinash kumar to Everyone:    12:15  PM
True

from iroti.mahajan to Everyone:    12:16  PM
True - Bcoz by using natural numbers we can perform operations

from Aradhana to Everyone:    12:16  PM
yes ...as it holds value

from Rohan Anarse to Everyone:    12:16  PM
false, natural number is just an one type of data.

from Avinash kumar to Everyone:    12:16  PM
natural number are +ve number

from Akash to Everyone:    12:16  PM
True - natural numbers is frm 0 to 9 and stores all data in byte codes format

from komal bhangale to Everyone:    12:16  PM
true : natural no can be a whole no..

from Anand to Everyone:    12:17  PM
True..as all data type use byte..

from Amar Rajendra kokare to Everyone:    12:17  PM
false,natural number is not datatypes bcs its a actual value

from Ashfaque Tanveer to Everyone:    12:17  PM
False : natural numbers are just one types of data.

from Dona Sonny to Everyone:    12:18  PM
false-it is a value that a data type can hold

_____________________________________________________________________
Java Language Specifications

The built-in integer operators do not indicate overflow or underflow in any way. 

Integer operators can throw a NullPointerException if unboxing conversion of a null reference is required. 

Other than that, the only integer operators that can throw an exception are the integer divide operator / and the integer remainder operator %, which throw an ArithmeticException if the right-hand operand is zero, and the increment and decrement operators ++ and -- which can throw an OutOfMemoryError if boxing conversion is required and there is insufficient memory to perform the conversion.

_____________________________________________________________________
SQL Injection Attack
_____________________________________________________________________

	SELECT * FROM db_user WHERE username='<USERNAME>' AND
                            password='<PASSWORD>'


	Suppose an attacker can substitute arbitrary strings for <USERNAME> and <PASSWORD>. In that case, the authentication mechanism can be bypassed by supplying the following <USERNAME> with an arbitrary password:


		validuser' OR '1'='1


	The authentication routine dynamically constructs the following query:

		SELECT * FROM db_user WHERE username='validuser' OR '1'='1' AND password='<PASSWORD>'


	Trusted-Based Systems
		User Will Supply Legal Username and Password

__________________________________________________________
SECURITY DESIGN PRINCIPLE
	NEVER TRUST EXTERNAL INPUTS
	NEVER DISCLOSE ANYTHING EXTRA IN OUPTPUT
__________________________________________________________


 - Do not perform bitwise and arithmetic operations on the same data

	int x = 50;
	x += (x << 2) + 1; // Comprehension of Code is Bad
	
	// Shift Operator is Efficient
	// Premature Optimisation is Bad Idea
	int x = 50;
	x = 5 * x + 1;



	// b[] is a byte array, initialized to 0xff
	byte[] b = new byte[] {-1, -1, -1, -1};

	int result = 0;
	for (int i = 0; i < 4; i++) {
		  result = ((result << 8) + b[i]);
	}

	In the bitwise operation, the value of the byte array element b[i] is promoted to an int by sign extension. 

	When a byte array element contains a negative value (for example, 0xff), the sign extension propagates 1-bits into the upper 24 bits of the int. This behavior might be unexpected if the programmer is assuming that byte is an unsigned type. In this example, adding the promoted byte values to result fails to result in a packed integer representation of the bytes


	int limit = (1 << 17) - 1; // 2^17 - 1 = 131071

_____________________________________________________________________
Ensure that division and remainder operations do not result in divide-by-zero errors
_____________________________________________________________________

	long num1, num2, result;
	 
	/* Initialize num1 and num2 */	 
	result = num1 / num2;

	//Follow Good Patterns
	// Use if/else rather try-catch
	if (num2 == 0) {
	  // Handle error
	} else {
	  result = num1 / num2;
	}

_____________________________________________________________________
Use integer types that can fully represent the possible range of unsigned data
_____________________________________________________________________

	public static int getInteger(DataInputStream is) throws IOException {
	  return is.readInt(); 
	}

	This noncompliant code example uses a generic method for reading integer data without considering the signedness of the source. It assumes that the data read is always signed and treats the most significant bit as the sign bit. When the data read is unsigned, the actual sign and magnitude of the values may be misinterpreted.

	public static long getInteger(DataInputStream is) throws IOException {
	  return is.readInt() & 0xFFFFFFFFL; // Mask with 32 one-bits
	}


_____________________________________________________________________
Do not use floating-point numbers if precise computation is required
	Because floating-point are approximate values of Real Number
_____________________________________________________________________

float f = 3.0f;
int i = 3;

// Non Deterministic Code

// Validation Logic
if ( i == f ) {
	// Validation Failed
	printf("Both Are Equal!");
} else {
	// Validation Passed
	printf("Both Are UnEqual!");
	// Access Provided
}

//BAD CODE
double dollar = 1.00;
double dime = 0.10;
int number = 7;
System.out.println(
  "A dollar less " + number + " dimes is $" + (dollar - number * dime) 
);

A dollar less 7 dimes is $0.29999999999999993

// GOOD CODE
int dollar = 100;
int dime = 10;
int number = 7;
System.out.println(
  "A dollar less " + number + " dimes is $0." + (dollar - number * dime)
);


// GOOD CODE
import java.math.BigDecimal;
 
BigDecimal dollar = new BigDecimal("1.0");
BigDecimal dime = new BigDecimal("0.1");
int number = 7;
System.out.println ("A dollar less " + number + " dimes is $" +
    (dollar.subtract(new BigDecimal(number).multiply(dime) )) );


_____________________________________________________________________
Do not attempt comparisons with NaN
_____________________________________________________________________

// BAD CODE
public class NaNComparison {
  public static void main(String[] args) {
    double x = 0.0;

    double result = Math.cos(1/x); 

    if (result == Double.NaN) {
      	System.out.println("result is NaN");
    } else{
    	System.out.println("result is NOT NaN");
    }
  }


// GOOD CODE
public class NaNComparison {
  public static void main(String[] args) {
    double x = 0.0;  
    double result = Math.cos(1/x);
    
    if (Double.isNaN(result)) {
      System.out.println("result is NaN");
    }
  }
}


_____________________________________________________________________
Check floating-point inputs for exceptional values
_____________________________________________________________________
// BAD CODE
double currentBalance; // User's cash balance
 
void doDeposit(String userInput) {
  double val = 0;
  try {
    val = Double.valueOf(userInput);
  } catch (NumberFormatException e) {
    // Handle input format error
  }
 
  if (val >= Double.MAX_VALUE - currentBalance) {
    // Handle range error
  }
 
  currentBalance += val;
}

This code produces unexpected results when an exceptional value is entered for val and subsequently used in calculations or as control values. The user could, for example, input the strings infinity or NaN on the command line, which would be parsed by Double.valueOf(String s) into the floating-point representations of either infinity or NaN. All subsequent calculations using these values would be invalid, possibly causing runtime exceptions or enabling denial-of-service (DoS) attacks.

In this noncompliant example, entering NaN for val would cause currentBalance to be set to NaN, corrupting its value. If this value were used in other expressions, every resulting value would also become NaN, possibly corrupting important data.
 
// GOOD CODE 
double currentBalance; // User's cash balance
 
void doDeposit(String userInput){
  double val = 0;
  try {
    val = Double.valueOf(userInput);
  } catch (NumberFormatException e) {
    // Handle input format error
  }
 
  if (Double.isInfinite(val)){
    // Handle infinity error
  }
 
  if (Double.isNaN(val)) {
    // Handle NaN error
  }
 
  if (val >= Double.MAX_VALUE - currentBalance) {
    // Handle range error
  }
  currentBalance += val;
}

__________________________________________________________

// BAD CODE - NON DETERMINISTIC
// How Many Times This Loop Will Run?
for (float x = 0.1f; x <= 1.0f; x += 0.1f) {
	System.out.println(x);
}

// BAD CODE
for (float x = 100000001.0f; x <= 100000010.0f; x += 1.0f) {
  	/* ... */
}


// Mathematical Induction : Use Integers for Counting
for (int count = 1; count <= 10; count += 1) {
  float x = count/10.0f;
  System.out.println(x);
}

_____________________________________________________________________
Do not construct BigDecimal objects from floating-point literals
_____________________________________________________________________

// FP-Strict Mode
// Prints 0.1000000000000000055511151231257827021181583404541015625
// NON - DETERMINISTICS

// BAD CODE
//						Mathematical Real Number
System.out.println(new BigDecimal( 0.1 ));

// Prints 0.1
// when run in FP-strict mode
System.out.println(new BigDecimal("0.1"));

_____________________________________________________________________
Do not compare or inspect the string representation of floating-point values
_____________________________________________________________________

// BAD CODE
int i = 1;
String s = Double.valueOf(i / 1000.0).toString();

if (s.equals("0.001")) {
  // ...
}

// BAD CODE
int i = 1;
String s = Double.valueOf(i / 1000.0).toString();
s = s.replaceFirst("[.0]*$", "");
if (s.equals("0.001")) {
  // ...
}

// GOOD CODE
int i = 1;
BigDecimal d = new BigDecimal(Double.valueOf(i / 1000.0).toString());
if (d.compareTo(new BigDecimal("0.001")) == 0) {
  // ...
}

_____________________________________________________________________
Ensure conversions of numeric types to narrower types do not result in lost or misinterpreted data
_____________________________________________________________________
	Java provides 22 possible narrowing primitive conversions. According to The Java Languagee Specification (JLS), §5.1.3, "Narrowing Primitive Conversions" [JLS 2015]:

	short to byte or char
	char to byte or short
	int to byte, short, or char
	long to byte, short, char, or int
	float to byte, short, char, int, or long
	double to byte, short, char, int, long, or float
	
	Narrowing primitive conversions are allowed in cases where the value of the wider type is within the range of the narrower type.

// BAD CODE
class CastAway {
  public static void main(String[] args) {
    int i = 128;
    workWith(i);
  }
 
  public static void workWith(int i) {
    byte b = (byte) i;  // b has value -128
    // Work with b
  }
}

// GOOD CODE
class CastAway {
  public static void workWith(int i) {
    // Check whether i is within byte range
    if ((i < Byte.MIN_VALUE) || (i > Byte.MAX_VALUE)) {
      throw new ArithmeticException("Value is out of range");
    }
 
    byte b = (byte) i;
    // Work with b
  }
}

// GOOD CODE
class CastAway {
   public static void workWith(int i) {
     byte b = (byte)(i % 0x100); // 2^8;
     // Work with b
   }
}


// BAD CODE
float i = Float.MIN_VALUE;
float j = Float.MAX_VALUE;
short b = (short) i;
short c = (short) j;


// GOOD CODE
float i = Float.MIN_VALUE;
float j = Float.MAX_VALUE;
if ((i < Short.MIN_VALUE) || (i > Short.MAX_VALUE) ||
    (j < Short.MIN_VALUE) || (j > Short.MAX_VALUE)) {
  throw new ArithmeticException ("Value is out of range");
}
 
short b = (short) i;
short c = (short) j;
// Other operations

// BAD CODE
double i = Double.MIN_VALUE;
double j = Double.MAX_VALUE;
float b = (float) i;
float c = (float) j;

//GOOD CODE
double i = Double.MIN_VALUE;
double j = Double.MAX_VALUE;
if ((i < Float.MIN_VALUE) || (i > Float.MAX_VALUE) ||
    (j < Float.MIN_VALUE) || (j > Float.MAX_VALUE)) {
  throw new ArithmeticException ("Value is out of range");
}
 
float b = (float) i;
float c = (float) j;
// Other operations


_____________________________________________________________________
Avoid loss of precision when converting primitive integers to floating-point
_____________________________________________________________________

The following 19 specific conversions on primitive types are called the widening primitive conversions:

	byte to short, int, long, float, or double
	short to int, long, float, or double
	char to int, long, float, or double
	int to long, float, or double
	long to float or double
	float to double

// BAD CODE
strictfp class WideSample {
  public static int subFloatFromInt(int op1, float op2) {
    return op1 - (int)op2; // Type Mess
  }
 
  public static void main(String[] args) {
    int result = subFloatFromInt(1234567890, 1234567890);
    // This prints -46, not 0, as may be expected
    System.out.println(result); 
  }
}

// GOOD CODE
strictfp class WideSample {
  public static int subFloatFromInt(int op1, float op2)
                    throws ArithmeticException {
 
    // The significand can store at most 23 bits
    if ((op2 > 0x007fffff) || (op2 < -0x800000)) {
      throw new ArithmeticException("Insufficient precision");
    }
 
    return op1 - (int)op2;
  }
 
  public static void main(String[] args) {
    int result = subFloatFromInt(1234567890, 1234567890);
    System.out.println(result); 
  }
}

_____________________________________________________________________
Use shift operators correctly
_____________________________________________________________________
Arithmetic vs. Logical Shift
__________________________________________________________
The JLS, §15.19 [JLS 2015], defines the behavior of the arithmetic shift operator as follows:

The value of n>>s is n right-shifted s bit positions with sign-extension. The resulting value is floor(n / 2s). For nonnegative values of n, this is equivalent to truncating integer division, as computed by the integer division operator /, by two to the power s.

The JLS also defines the behavior of the logical shift operator:

The value of n >>> s is n right-shifted s bit positions with zero-extension, where:

  • If n is positive, then the result is the same as that of n >> s.

  • If n is negative and the type of the left-hand operand is int, then the result is equal to that of the expression (n >> s) + (2 << ~s).

  • If n is negative and the type of the left-hand operand is long, then the result is equal to that of the expression (n >> s) + (2L << ~s).

The added term (2 << ~s) or (2L << ~s) cancels out the propagated sign bit.

Note that, because of the implicit masking of the right-hand operand of a shift operator, ~s as a shift distance is equivalent to 31-s when shifting an int value and to 63-s when shifting a long value.

Never use the arithmetic shift operator when the logical shift operator is required.

_____________________________________________________________________
Normalize strings before validating them
_____________________________________________________________________

Character information in Java is based on the Unicode Standard. The following table shows the version of Unicode supported by the latest three releases of Java SE.

	Java SE 6	Unicode Standard, version 4.0 [Unicode 2003]
	Java SE 7	Unicode Standard, version 6.0.0 [Unicode 2011]
	Java SE 8	Unicode Standard, version 6.2.0 [Unicode 2012]

The Normalizer.normalize() method transforms Unicode text into the standard normalization forms described in Unicode Standard Annex #15 Unicode Normalization Forms. 

Frequently, the most suitable normalization form for performing input validation on arbitrarily encoded strings is KC (NFKC) .


// BAD CODE
// String s may be user controllable
// \uFE64 is normalized to < and \uFE65 is normalized to > using the NFKC normalization form
String s = "\uFE64" + "script" + "\uFE65";
 
// Validate
Pattern pattern = Pattern.compile("[<>]"); // Check for angle brackets
Matcher matcher = pattern.matcher(s);

if (matcher.find()) {
  // Found black listed tag
  throw new IllegalStateException();
} else {
  // ...
}
 
// Normalize
s = Normalizer.normalize(s, Form.NFKC);

__________________________________________________________

String s = "\uFE64" + "script" + "\uFE65";
 
// Normalize
s = Normalizer.normalize(s, Form.NFKC);
 
// Validate
Pattern pattern = Pattern.compile("[<>]");
Matcher matcher = pattern.matcher(s);
if (matcher.find()) {
  // Found blacklisted tag
  throw new IllegalStateException();
} else {
  // ...
}

_____________________________________________________________________
Canonicalize path names before validating them
_____________________________________________________________________

// BAD CODE
File file = new File("/img/" + args[0]);
if (!isInSecureDir(file)) {
  throw new IllegalArgumentException();
}
FileOutputStream fis = new FileOutputStream(file);
// ...


// GOOD CODE
File file = new File("/img/" + args[0]);
if (!isInSecureDir(file)) {
  throw new IllegalArgumentException();
}

String canonicalPath = file.getCanonicalPath();
if (!canonicalPath.equals("/img/java/file1.txt") &&
    !canonicalPath.equals("/img/java/file2.txt")) {
   // Invalid file; handle error
}
 
FileInputStream fis = new FileInputStream(f);

__________________________________________________________

According to the Java API [API 2006] for class java.io.File:

A pathname, whether abstract or in string form, may be either absolute or relative. An absolute pathname is complete in that no other information is required to locate the file that it denotes. A relative pathname, in contrast, must be interpreted in terms of information taken from some other pathname.

Absolute or relative path names may contain file links such as symbolic (soft) links, hard links, shortcuts, shadows, aliases, and junctions. 

These file links must be fully resolved before any file validation operations are performed. For example, the final target of a symbolic link called trace might be the path name /home/system/trace. Path names may also contain special file names that make validation difficult:

"." refers to the directory itself.
Inside a directory, the special file name ".." refers to the directory's parent directory.


__________________________________________________________

Canonicalizing file names makes it easier to validate a path name. More than one path name can refer to a single directory or file. 

	Further, the textual representation of a path name may yield little or no information regarding the directory or file to which it refers. Consequently, all path names must be fully resolved or canonicalized before validation.

		"img/someFile.txt"

		"/Users/Deepak/Documents/img/someFile.txt"
		"passw\u7878"
		"passwd"
		"/etc/passwd"

Validation may be necessary, for example, when attempting to restrict user access to files within a particular directory or to otherwise make security decisions based on the name of a file name or path name. Frequently, these restrictions can be circumvented by an attacker by exploiting a directory traversal or path equivalence vulnerability. A directory traversal vulnerability allows an I/O operation to escape a specified operating directory. A path equivalence vulnerability occurs when an attacker provides a different but equivalent name for a resource to bypass security checks.

__________________________________________________________
	//BAD CODE
	File file = new File("/img/" + args[0]);
	if (!isInSecureDir(file)) {
	  throw new IllegalArgumentException();
	}

	FileOutputStream fis = new FileOutputStream(file);
	// ...

	//BAD CODE - ORDER MESS
	File file = new File("/img/" + args[0]);
	if (!isInSecureDir(file)) {
	  throw new IllegalArgumentException();
	}

	String canonicalPath = file.getCanonicalPath();
	FileOutputStream fis = new FileOutputStream(canonicalPath);
__________________________________________________________	
	// GOOD CODE
	File file = new File("/img/" + args[0]);

	// Directory is Treated As Sandbox
	if (!isInSecureDir(file)) {
	  throw new IllegalArgumentException();
	}

	// Access Privelages 
	if ( !isNotValidApplicatioID(applicationID) ) {
  		throw new AccessDeniedException();
	}

	String canonicalPath = file.getCanonicalPath();
	// Compare With WhiteList of Paths
	if (!canonicalPath.equals("/img/java/file1.txt") &&
	    !canonicalPath.equals("/img/java/file2.txt")) {
	   // Invalid file; handle error
	}
	 
	FileInputStream fis = new FileInputStream(f);

__________________________________________________________
	Security Manager

	// All files in /img/java can be read
	grant codeBase "file:/home/programpath/" {
	  permission java.io.FilePermission "/img/java", "read";
	};

__________________________________________________________
SECURITY DESIGN PRINCIPLE
	DESIGN TOWARDS SANDBOXING
__________________________________________________________


__________________________________________________________
Do not log unsanitized user input
__________________________________________________________

	if (loginSuccessful) {
	  logger.severe("User login succeeded for: " + username);
	} else {
	  logger.severe("User login failed for: " + username);
	}


Without sanitization, a log injection attack is possible. A standard log message when username is guest might look like this:


May 15, 2011 2:19:10 PM java.util.logging.LogManager$RootLogger log

	SEVERE: User login failed for: guest
	If the username that is used in a log message is not guest but rather a multiline string like this:

guest
May 15, 2011 2:25:52 PM java.util.logging.LogManager$RootLogger log
	SEVERE: User login succeeded for: administrator
	the log would contain the following misleading data:

May 15, 2011 2:19:10 PM java.util.logging.LogManager$RootLogger log
	SEVERE: User login failed for: guest
	May 15, 2011 2:25:52 PM java.util.logging.LogManager log
	SEVERE: User login succeeded for: administrator

__________________________________________________________
// GOOD CODE

public String sanitizeUser(String username) {
	// Check WhiteList
  return Pattern.matches("[A-Za-z0-9_]+", username))
      ? username : "unauthorized user";

	// Check BlackList
}

if (loginSuccessful) {
  logger.severe("User login succeeded for: " + sanitizeUser(username));
} else {
  logger.severe("User login failed for: " + sanitizeUser(username));
}

__________________________________________________________
// GOOD CODE
class SanitizedTextLogger extends Logger {
  Logger delegate;
 
  public SanitizedTextLogger(Logger delegate) {
    super(delegate.getName(), delegate.getResourceBundleName());
    this.delegate = delegate;
  }
 
  public String sanitize(String msg) {
    Pattern newline = Pattern.compile("\n");
    Matcher matcher = newline.matcher(msg);
    return matcher.replaceAll("\n  ");
  }
 
  public void severe(String msg) {
    delegate.severe(sanitize(msg));
  }
 
  // .. Other Logger methods which must also sanitize their log messages
}

Logger sanLogger = new SanitizedTextLogger(logger);
 
if (loginSuccessful) {
  sanLogger.severe("User login succeeded for: " + username);
} else {
  sanLogger.severe("User login failed for: " + username);
}

_____________________________________________________________________
Safely extract files from ZipInputStream
_____________________________________________________________________
RESOUCES DENIAL ATTACK USING ZIP BOMBS
WIPING DATA USING ZIP BOMBS
INSTALLING/OVERIRIDING DATA/EXECTABLES/LIBRARIES AT SYSTEM DIRECTORIES

A number of security concerns must be considered when extracting file entries from a ZIP file using java.util.zip.ZipInputStream. File names may contain path traversal information that may cause them to be extracted outside of the intended directory, frequently with the purpose of overwriting existing system files. Directory traversal or path equivalence vulnerabilities can be eliminated by canonicalizing the path name, in accordance with FIO16-J. Canonicalize path names before validating them, and then validating the location before extraction.

A second issue is that the extraction process can cause excessive consumption of system resources, possibly resulting in a denial-of-service attack when resource usage is disproportionately large compared to the input data. The zip algorithm can produce very large compression ratios [Mahmoud 2002]. For example, a file consisting of alternating lines of a characters and b characters can achieve a compression ratio of more than 200 to 1. Even higher compression ratios can be obtained using input data that is targeted to the compression algorithm. 

This permits the existence of zip bombs in which a small ZIP or GZIP file consumes excessive resources when uncompressed. An example of a zip bomb is the file 42.zip, which is a zip file consisting of 42 kilobytes of compressed data, 

	containing five layers of nested zip files in sets of 16, each bottom layer archive containing a 4.3 gigabyte (4 294 967 295 bytes; ~ 3.99 GiB) file for a total of 4.5 petabytes (4 503 599 626 321 920 bytes; ~ 3.99 PiB) of uncompressed data. 

	Zip bombs often rely on repetition of identical files to achieve their extreme compression ratios. 

	Programs must either limit the traversal of such files or refuse to extract data beyond a certain limit. The actual limit depends on the capabilities of the platform and expected usage.

__________________________________________________________
// BAD CODE
static final int BUFFER = 512;
// ...
 
public final void unzip(String filename) throws java.io.IOException{
  FileInputStream fis = new FileInputStream(filename);
  ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
  ZipEntry entry;

  try {

    while ((entry = zis.getNextEntry()) != null) {
      System.out.println("Extracting: " + entry);
      int count;
      byte data[] = new byte[BUFFER];
      // Write the files to the disk
      FileOutputStream fos = new FileOutputStream(entry.getName());
      BufferedOutputStream dest = new BufferedOutputStream(fos, BUFFER);
      while ((count = zis.read(data, 0, BUFFER)) != -1) {
        dest.write(data, 0, count);
      }
      dest.flush();
      dest.close();
      zis.closeEntry();
    }
  } finally {
    zis.close();
  }
}

__________________________________________________________
// BAD CODE
static final int BUFFER = 512;
static final int TOOBIG = 0x6400000; // 100MB
// ...
 
public final void unzip(String filename) throws java.io.IOException{
  FileInputStream fis = new FileInputStream(filename);
  ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
  ZipEntry entry;
  try {
    while ((entry = zis.getNextEntry()) != null) {
      System.out.println("Extracting: " + entry);
      int count;
      byte data[] = new byte[BUFFER];
      
      // Write the files to the disk, but only if the file is not insanely big
      if (entry.getSize() > TOOBIG ) {
         throw new IllegalStateException("File to be unzipped is huge.");
      }

      if (entry.getSize() == -1) {
         throw new IllegalStateException("File to be unzipped might be huge.");
      }

      FileOutputStream fos = new FileOutputStream(entry.getName());
      BufferedOutputStream dest = new BufferedOutputStream(fos, BUFFER);
      
      while ((count = zis.read(data, 0, BUFFER)) != -1) {
        dest.write(data, 0, count);

      }

      dest.flush();
      dest.close();
      zis.closeEntry();
    }
  } finally {
    zis.close();
  }
}

__________________________________________________________
// GOOD CODE
static final int BUFFER = 512;
static final long TOOBIG = 0x6400000; // Max size of unzipped data, 100MB
static final int TOOMANY = 1024;      // Max number of files
// ...
 
private String validateFilename(String filename, String intendedDir)
      throws java.io.IOException {
  File f = new File(filename);
  String canonicalPath = f.getCanonicalPath();
 
  File iD = new File(intendedDir);
  String canonicalID = iD.getCanonicalPath();
   
  if (canonicalPath.startsWith(canonicalID)) {
    return canonicalPath;
  } else {
    throw new IllegalStateException("File is outside extraction target directory.");
  }
}
 
public final void unzip(String filename) throws java.io.IOException {
  FileInputStream fis = new FileInputStream(filename);
  ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
  ZipEntry entry;
  int entries = 0;
  long total = 0;
  
  try {
    while ((entry = zis.getNextEntry()) != null) {
      System.out.println("Extracting: " + entry);
      int count;
      byte data[] = new byte[BUFFER];
      // Write the files to the disk, but ensure that the filename is valid,
      // and that the file is not insanely big
      String name = validateFilename(entry.getName(), ".");

      if (entry.isDirectory()) {
      	// Check isDirectory Within Sandbox Directory
        System.out.println("Creating directory " + name);
        new File(name).mkdir();
        continue;
      }

      FileOutputStream fos = new FileOutputStream(name);
      BufferedOutputStream dest = new BufferedOutputStream(fos, BUFFER);

      while (total + BUFFER <= TOOBIG && (count = zis.read(data, 0, BUFFER)) != -1) {
        dest.write(data, 0, count);
        total += count;
      }

      dest.flush();
      dest.close();
      zis.closeEntry();
      
      entries++;

      if (entries > TOOMANY) {
        throw new IllegalStateException("Too many files to unzip.");
      }
      if (total + BUFFER > TOOBIG) {
        throw new IllegalStateException("File being unzipped is too big.");
      }
    }
  } finally {
    zis.close();
  }
}

_____________________________________________________________________
Use conservative file naming conventions
_____________________________________________________________________

File and path names containing particular characters or character sequences can cause problems when used in the construction of a file or path name:

	Leading dashes: Leading dashes can cause problems when programs are called with the file name as a parameter because the first character or characters of the file name might be interpreted as an option switch.

	Control characters, such as newlines, carriage returns, and escape: Control characters in a file name can cause unexpected results from shell scripts and in logging.

	Spaces: Spaces can cause problems with scripts and when double quotes are not used to surround the file name.

	Invalid character encodings: Character encodings can make it difficult to perform proper validation of file and path names. (See IDS11-J. Perform any string modifications before validation).

	Namespace prefixing and conventions: Namespace prefixes can cause unexpected and potentially insecure behavior when included in a path name.

	Command interpreters, scripts, and parsers: Characters that have special meaning when processed by a command interpreter, shell, or parser.


As a result of the influence of MS-DOS, 8.3 file names of the form xxxxxxxx.xxx, where x denotes an alphanumeric character, are generally supported by modern systems. 

	On some platforms, file names are case sensitive, and on other platforms, they are case insensitive. 

	VU#439395 is an example of a vulnerability resulting from a failure to deal appropriately with case sensitivity issues [VU#439395].  

// BAD CODE
File f = new File("A\uD8AB");
OutputStream out = new FileOutputStream(f);

//GOOD CODE
File f = new File("name.ext");
OutputStream out = new FileOutputStream(f);


Developers should generate file and path names using a safe subset of ASCII characters and, for security critical applications, only accept names that use these characters.

// GOOD CODE
public static void main(String[] args) throws Exception {
  if (args.length < 1) {
    // Handle error
  }
  String filename = args[0];
 
  Pattern pattern = Pattern.compile("[^A-Za-z0-9._]");
  Matcher matcher = pattern.matcher(filename);
  if (matcher.find()) {
    // File name contains bad chars; handle error
  }
  File f = new File(filename);
  OutputStream out = new FileOutputStream(f);
  // ...
}

__________________________________________________________

It is important that a string not be modified after validation has occurred because doing so may allow an attacker to bypass validation. 

	For example, a program may filter out the <script> tags from HTML input to avoid cross-site scripting (XSS) and other vulnerabilities. 

	If exclamation marks (!) are deleted from the input following validation, an attacker may pass the string "<scr!ipt>" so that the validation check fails to detect the <script> tag, but the subsequent removal of the exclamation mark creates a <script> tag in the input. 
__________________________________________________________
// BAD CODE
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
  
public class TagFilter {
  public static String filterString(String str) {
    String s = Normalizer.normalize(str, Form.NFKC);
 
    // Validate input
    Pattern pattern = Pattern.compile("<script>");
    Matcher matcher = pattern.matcher(s);
    if (matcher.find()) {
      throw new IllegalArgumentException("Invalid input");
    }
 
    // Deletes noncharacter code points
    s = s.replaceAll("[\\p{Cn}]", "");
    return s;
  }
 
  public static void main(String[] args) {
    // "\uFDEF" is a noncharacter code point
    String maliciousInput = "<scr" + "\uFDEF" + "ipt>"; //<str!ipt>
    String sb = filterString(maliciousInput);
    // sb = "<script>"
  }
}

__________________________________________________________

// GOOD CODE
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
public class TagFilter {
  
  public static String filterString(String str) {
    String s = Normalizer.normalize(str, Form.NFKC);
 
    // Replaces all noncharacter code points with Unicode U+FFFD
    s = s.replaceAll("[\\p{Cn}]", "\uFFFD");
 
    // Validate input
    Pattern pattern = Pattern.compile("<script>");
    Matcher matcher = pattern.matcher(s);
    if (matcher.find()) {
      throw new IllegalArgumentException("Invalid input");
    }
    return s;
  }
  public static void main(String[] args) {
    // "\uFDEF" is a non-character code point
    String maliciousInput = "<scr" + "\uFDEF" + "ipt>";
    String s = filterString(maliciousInput);
    // s = <scr?ipt>
  }

_____________________________________________________________________
Exclude unsanitized user input from format strings
_____________________________________________________________________
//BAD CODE
class Format {
  static Calendar c = new GregorianCalendar(1995, GregorianCalendar.MAY, 23);

  public static void main(String[] args) { 
    // args[0] should contain the credit card expiration date
    // but might contain %1$tm, %1$te or %1$tY format specifiers
  	
  	validateCreditCard(args);
  }

  private static void validateCreditCard(String[] args) {
  	final creditCardExpirationDate = Date("");  // Populated Database  
    System.out.format(
      args[0] + " did not match! HINT: It was issued on %1$terd of some month", c);

	if ( creditCardExpirationDate == args[1] ) {

    }
  }
}

This noncompliant code example leaks information about a user's credit card. It incorporates untrusted data in a format string.

In the absence of proper input validation, an attacker can determine the date against which the input is verified by supplying an input string that includes the %1$tm, %1$te, or %1$tY format specifiers. 

In this example, these format specifiers print 05 (May), 23 (day), and 1995 (year), respectively.


// GOOD CODE
class Format {
  static Calendar c =
    new GregorianCalendar(1995, GregorianCalendar.MAY, 23);
  public static void main(String[] args) { 
    // args[0] is the credit card expiration date
    // Perform comparison with c,
    // if it doesn't match, print the following line
    System.out.format(
      "%s did not match! HINT: It was issued on %terd of some month", 
      args[0], c);
  }
}

_____________________________________________________________________
Sanitize untrusted data passed to the Runtime.exec() method

COMMAND INJECTION
_____________________________________________________________________

// BAD CODE - Windows OS
class DirList {
  public static void main(String[] args) throws Exception {
    String dir = System.getProperty("dir");
    Runtime rt = Runtime.getRuntime();

    Process proc = rt.exec("cmd.exe /C dir " + dir);

    int result = proc.waitFor();
    if (result != 0) {
      System.out.println("process error: " + result);
    }
    InputStream in = (result == 0) ? proc.getInputStream() :
                                     proc.getErrorStream();
    int c;
    while ((c = in.read()) != -1) {
      System.out.print((char) c);
    }
  }
}


An attacker can exploit this program using the following command:

	java -Ddir='dummy & echo bad' Java

The command executed is actually two commands:

	cmd.exe /C dir dummy & echo bad

which first attempts to list a nonexistent dummy folder and then prints bad to the console.

// BAD CODE - UNIX 
class DirList {
  public static void main(String[] args) throws Exception {
    String dir = System.getProperty("dir");
    Runtime rt = Runtime.getRuntime();
    
    Process proc = rt.exec(new String[] {"sh", "-c", "ls " + dir});
    
    int result = proc.waitFor();
    if (result != 0) {
      System.out.println("process error: " + result);
    }
    InputStream in = (result == 0) ? proc.getInputStream() :
                                     proc.getErrorStream();
    int c;
    while ((c = in.read()) != -1) {
      System.out.print((char) c);
    }
  }
}

// White Listing Is Better IDEA
// ...
String dir = null;
 
int number = Integer.parseInt(System.getProperty("dir")); // Only allow integer choices
switch (number) {
  case 1:
    dir = "data1";
    break; // Option 1
  case 2:
    dir = "data2";
    break; // Option 2
  default: // Invalid
    break;
}

if (dir == null) {
  // Handle error
}


// Prefer Java Library Functions Rather Than exec()
import java.io.File;
 
class DirList {
  public static void main(String[] args) throws Exception {
    File dir = new File(System.getProperty("dir"));
    if (!dir.isDirectory()) {
      System.out.println("Not a directory");
    } else {
      for (String file : dir.list()) {
        System.out.println(file);
      }
    }
  }
}

_____________________________________________________________________
Sanitize untrusted data included in a regular expression

REGEX INJECTION
_____________________________________________________________________
Java's powerful regex facilities must be protected from misuse. An attacker may supply a malicious input that modifies the original regular expression in such a way that the regex fails to comply with the program's specification. 

This attack vector, called a regex injection, might affect control flow, cause information leaks, or result in denial-of-service (DoS) vulnerabilities.

Certain constructs and properties of Java regular expressions are susceptible to exploitation:

Matching flags: Untrusted inputs may override matching options that may or may not have been passed to the Pattern.compile() method.
Greediness: An untrusted input may attempt to inject a regex that changes the original regex to match as much of the string as possible, exposing sensitive information.
Grouping: The programmer can enclose parts of a regular expression in parentheses to perform some common action on the group. An attacker may be able to change the groupings by supplying untrusted input.
Untrusted input should be sanitized before use to prevent regex injection. When the user must specify a regex as input, care must be taken to ensure that the original regex cannot be modified without restriction. Whitelisting characters (such as letters and digits) before delivering the user-supplied string to the regex parser is a good input sanitization strategy. A programmer must provide only a very limited subset of regular expression functionality to the user to minimize any chance of misuse.

10:47:03 private[423] Successful logout  name: usr1 ssn: 111223333
10:47:04 public[48964] Failed to resolve network service
10:47:04 public[1] (public.message[49367]) Exited with exit code: 255
10:47:43 private[423] Successful login  name: usr2 ssn: 444556666
10:48:08 public[48964] Backup failed with error: 19


(.*? +public\[\d+\] +.*<SEARCHTEXT>.*)

However, if an attacker can substitute any string for <SEARCHTEXT>, he can perform a regex injection with the following text:

	.*)|(.*


When injected into the regex, the regex becomes

	(.*? +public\[\d+\] +.*.*) | (.*.*)

// BAD CODE

	import java.io.FileInputStream;
import java.io.IOException;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
public class LogSearch {
    public static void FindLogEntry(String search) {
        // Construct regex dynamically from user string
        String regex = "(.*? +public\\[\\d+\\] +.*" + search + ".*)";
   
        Pattern searchPattern = Pattern.compile(regex);
        try (FileInputStream fis = new FileInputStream("log.txt")) {
            FileChannel channel = fis.getChannel();
            // Get the file's size and map it into memory
            long size = channel.size();
            final MappedByteBuffer mappedBuffer = channel.map(
                    FileChannel.MapMode.READ_ONLY, 0, size);
            Charset charset = Charset.forName("ISO-8859-15");
            final CharsetDecoder decoder = charset.newDecoder();
            // Read file into char buffer
            CharBuffer log = decoder.decode(mappedBuffer);
            Matcher logMatcher = searchPattern.matcher(log);
            while (logMatcher.find()) {
                String match = logMatcher.group();
                if (!match.isEmpty()) {
                    System.out.println(match);
                }
            }
        } catch (IOException ex) {
            System.err.println("thrown exception: " + ex.toString());
            Throwable[] suppressed = ex.getSuppressed();
            for (int i = 0; i < suppressed.length; i++) {
                System.err.println("suppressed exception: "
                        + suppressed[i].toString());
            }
        }
        return;
    }

// GOOD CODE - WHITELISTING
public static void FindLogEntry(String search) {
    // Sanitize search string
    StringBuilder sb = new StringBuilder(search.length());
    
    for (int i = 0; i < search.length(); ++i) {
        char ch = search.charAt(i);
        if (Character.isLetterOrDigit(ch) || ch == ' ' || ch == '\'') {
            sb.append(ch);
        }
    }
    search = sb.toString();
 
    // Construct regex dynamically from user string
    String regex = "(.*? +public\\[\\d+\\] +.*" + search + ".*)";
    // ...
}

// Pattern.quote()
public static void FindLogEntry(String search) {
    // Sanitize search string
    search = Pattern.quote(search);
    // Construct regex dynamically from user string
    String regex = "(.*? +public\\[\\d+\\] +.*" + search + ".*)";
    // ...
}

_____________________________________________________________________
Specify an appropriate locale when comparing locale-dependent data
_____________________________________________________________________

public class Example {
  public static void main(String[] args) {
    System.out.println("Title".toUpperCase());
  }
}


% java Example
TITLE
%

% java -Duser.language=tr Example
TİTLE
%

__________________________________________________________
// BAD CODE
public static void processTag(String tag) {
  if (tag.toUpperCase().equals("SCRIPT")) {
    return;
  }
  // Process tag
}

//GOOD CODE
public static void processTag(String tag) {
  if (tag.toUpperCase(Locale.ENGLISH).equals("SCRIPT")) {
    return;
  }
  // Process tag
}

//GOOD CODE
public static void processTag(String tag) {
  Locale.setDefault(Locale.ENGLISH);
 
  if (tag.toUpperCase().equals("SCRIPT")) {
    return;
  }
  // Process tag
}


//GOOD CODE
public static void processTag(String tag) {
  if (tag.equalsIgnoreCase("SCRIPT")) {
    return;
  }
  // Process tag
}

This compliant solution bypasses locales entirely by performing a case-insensitive match. The String.equalsIgnoreCase() method creates temporary canonical forms of both strings, which may render them unreadable, but it performs proper comparison without making them dependent on the current locale [Schindler 12].

__________________________________________________________

import java.io.*;
 
public class PrintMyself {
  private static String inputFile = "PrintMyself.java";
  private static String outputFile = "PrintMyself.txt";
 
  public static void main(String[] args) throws IOException {
    BufferedReader reader = new BufferedReader(new FileReader(inputFile));
    PrintWriter writer = new PrintWriter(new FileWriter(outputFile));
    int line = 0;
    while (reader.ready()) {
      line++;
      writer.println(line + ": " + reader.readLine());
    }
    reader.close();
    writer.close();
  }
}

// GOOD CODE
public static void main(String[] args) throws IOException {
  Charset encoding = Charset.forName("UTF8");
  BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), encoding));
  PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(outputFile), encoding));
 
  int line = 0;
 
  /* Rest of code unchanged */


// BAD CODE
import java.util.Date;
import java.text.DateFormat;
import java.util.Locale;
 
// ...
 
public static void isJune(Date date) {
  String myString = DateFormat.getDateInstance().format(date);
  System.out.println("The date is " + myString);
  if (myString.startsWith("Jun ")) {
    System.out.println("Enjoy June!");
  } else {
    System.out.println("It's not June.");
  }
}

The concepts of days and years are universal, but the way in which dates are represented varies across cultures and are therefore specific to locales. This noncompliant code example examines the current date and prints one of two messages, depending on whether or not the month is June:

String myString = DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.US).format(rightNow.getTime());
/* Rest of code unchanged */

_____________________________________________________________________
Do not assume that a Java char fully represents a Unicode code point
_____________________________________________________________________

// BAD CODE
public static String trim(String string) {
  char ch;
  int i;
  for (i = 0; i < string.length(); i += 1) {
    ch = string.charAt(i);
    if (!Character.isLetter(ch)) {
      break;
    }
  }
  return string.substring(i);
}

Unfortunately, the trim() method may fail because it is using the character form of the Character.isLetter() method. Methods that accept only a char value cannot support supplementary characters. According to the Java API [API 2014] class Character documentation

	They treat char values from the surrogate ranges as undefined characters. 

	For example, Character.isLetter('\uD840') returns false, even though this specific value if followed by any low-surrogate value in a string would represent a letter.

// GOOD CODE
public static String trim(String string) {
  int ch;
  int i;
  for (i = 0; i < string.length(); i += Character.charCount(ch)) {
    ch = string.codePointAt(i);
    if (!Character.isLetter(ch)) {
      break;
    }
  }
  return string.substring(i);
}

This compliant solution corrects the problem with supplementary characters by using the integer form of the Character.isLetter() method that accepts a Unicode code point as an int argument. Java library methods that accept an int value support all Unicode characters, including supplementary characters.
__________________________________________________________
The char data type is based on the original Unicode specification, which defined characters as fixed-width 16-bit entities. The Unicode Standard has since been changed to allow for characters whose representation requires more than 16 bits. The range of Unicode code points is now U+0000 to U+10FFFF. The set of characters from U+0000 to U+FFFF is called the basic multilingual plane (BMP), and characters whose code points are greater than U+FFFF are called supplementary characters. Such characters are generally rare, but some are used, for example, as part of Chinese and Japanese personal names. To support supplementary characters without changing the char primitive data type and causing incompatibility with previous Java programs, supplementary characters are defined by a pair of Unicode code units called surrogates. According to the Java API [API 2014] class Character documentation (Unicode Character Representations):


	The Java platform uses the UTF-16 representation in char arrays and in the String and StringBuffer classes. In this representation, supplementary characters are represented as a pair of char values, the first from the high-surrogates range, (\uD800-\uDBFF), the second from the low-surrogates range (\uDC00-\uDFFF).


A char value, therefore, represents BMP code points, including the surrogate code points, or code units of the UTF-16 encoding. 

An int value represents all Unicode code points, including supplementary code points. The lower (least significant) 21 bits of int are used to represent Unicode code points, and the upper (most significant) 11 bits must be zero. Similar to UTF-8 (see STR00-J. 

	Don't form strings containing partial characters from variable-width encodings), UTF-16 is a variable-width encoding. Because the UTF-16 representation is also used in char arrays and in the String and StringBuffer classes, care must be taken when manipulating string data in Java. 

	In particular, do not write code that assumes that a value of the primitive type char (or a Character object) fully represents a Unicode code point. 

	Conformance with this requirement typically requires using methods that accept a Unicode code point as an int value and avoiding methods that accept a Unicode code unit as a char value because these latter methods cannot support supplementary characters.

_____________________________________________________________________
Use compatible character encodings when communicating string data between JVMs
_____________________________________________________________________


FileInputStream fis = null;
try {
  fis = new FileInputStream("SomeFile");
  DataInputStream dis = new DataInputStream(fis);
  byte[] data = new byte[1024];
  dis.readFully(data);
  String result = new String(data);
} catch (IOException x) {
  // Handle error
} finally {
  if (fis != null) {
    try {
      fis.close();
    } catch (IOException x) {
      // Forward to handler
    }
  }
}

__________________________________________________________
This compliant solution explicitly specifies the character encoding used to create the string (in this example, UTF-16LE) as the second argument to the String constructor. The LE form of UTF-16 uses little-endian byte serialization (least significant byte first). Provided that the character data was encoded in UTF-16LE, it will decode correctly

// GOOD CODE
FileInputStream fis = null;
try {
  fis = new FileInputStream("SomeFile");
  DataInputStream dis = new DataInputStream(fis);
  byte[] data = new byte[1024];
  dis.readFully(data);

  String result = new String(data, "UTF-16LE"); // IMPORTANT

} catch (IOException x) {
  // Handle error
} finally {
  if (fis != null) {
    try {
      fis.close();
    } catch (IOException x) {
      // Forward to handler
    }
  }
}

_____________________________________________________________________
Prevent XML Injection
_____________________________________________________________________

The extensible markup language (XML) is designed to help store, structure, and transfer data. Because of its platform independence, flexibility, and relative simplicity, XML has found use in a wide range of applications. 

However, because of its versatility, XML is vulnerable to a wide spectrum of attacks, including XML injection.

A user who has the ability to provide input string data that is incorporated into an XML document can inject XML tags. 

	These tags are interpreted by the XML parser and may cause data to be overridden.

An online store application that allows the user to specify the quantity of an item available for purchase might generate the following XML document:

	<item>
	  <description>Widget</description>
	  <price>500.0</price>
	  <quantity>1</quantity>
	</item>


An attacker might input the following string instead of a count for the quantity:

	1</quantity><price>1.0</price><quantity>1

In this case, the XML resolves to the following:

	<item>
	  <description>Widget</description>
	  <price>500.0</price>
	  <quantity>1</quantity>
	  <price>1.0</price>
	  <quantity>1</quantity>
	</item>

An XML parser may interpret the XML in this example such that the second price field overrides the first, changing the price of the item to $1. 

Alternatively, the attacker may be able to inject special characters, such as comment blocks and CDATA delimiters, which corrupt the meaning of the XML.

// BAD CODE
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
 
public class OnlineStore {
  private static void createXMLStreamBad(final BufferedOutputStream outStream,
      final String quantity) throws IOException {
    String xmlString = "<item>\n<description>Widget</description>\n"
        + "<price>500</price>\n" + "<quantity>" + quantity
        + "</quantity></item>";
    outStream.write(xmlString.getBytes());
    outStream.flush();
  }
}

// GOOD BAD
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
 
public class OnlineStore {
  private static void createXMLStream(final BufferedOutputStream outStream,
      final String quantity) throws IOException, NumberFormatException {
    // Write XML string only if quantity is an unsigned integer (count).
    int count = Integer.parseUnsignedInt(quantity);
    String xmlString = "<item>\n<description>Widget</description>\n"
        + "<price>500</price>\n" + "<quantity>" + count + "</quantity></item>";
    outStream.write(xmlString.getBytes());
    outStream.flush();
  }
}

__________________________________________________________
// GOOD CODE
// XML Schema - Stored schema.xsd File
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
<xs:element name="item">
  <xs:complexType>
    <xs:sequence>
      <xs:element name="description" type="xs:string"/>
      <xs:element name="price" type="xs:decimal"/>
      <xs:element name="quantity" type="xs:nonNegativeInteger"/>
    </xs:sequence>
  </xs:complexType>
</xs:element>
</xs:schema>

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
 
import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
 
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
 
public class OnlineStore {
 
  private static void createXMLStream(final BufferedOutputStream outStream,
      final String quantity) throws IOException {
    String xmlString;
    xmlString = "<item>\n<description>Widget</description>\n"
        + "<price>500.0</price>\n" + "<quantity>" + quantity
        + "</quantity></item>";
    InputSource xmlStream = new InputSource(new StringReader(xmlString));
    
    // Build a validating SAX parser using our schema
    SchemaFactory sf = SchemaFactory
        .newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
    
    DefaultHandler defHandler = new DefaultHandler() {
      public void warning(SAXParseException s) throws SAXParseException {
        throw s;
      }
      public void error(SAXParseException s) throws SAXParseException {
        throw s;
      }
      public void fatalError(SAXParseException s) throws SAXParseException {
        throw s;
      }
    };

    StreamSource ss = new StreamSource(new File("schema.xsd"));
    try {
      Schema schema = sf.newSchema(ss);
      SAXParserFactory spf = SAXParserFactory.newInstance();
    
      spf.setSchema(schema);
    
      SAXParser saxParser = spf.newSAXParser();
      // To set the custom entity resolver,
      // an XML reader needs to be created
    
      XMLReader reader = saxParser.getXMLReader();
      
      reader.setEntityResolver(new CustomResolver());
      saxParser.parse(xmlStream, defHandler);

    } catch (ParserConfigurationException x) {
      throw new IOException("Unable to validate XML", x);
    } catch (SAXException x) {
      throw new IOException("Invalid quantity", x);
    }
    // Our XML is valid, proceed
    outStream.write(xmlString.getBytes());
    outStream.flush();
  }
}


_____________________________________________________________________
Prevent XML External Entity Attacks [ XXE Attack ]
_____________________________________________________________________

Entity declarations define shortcuts to commonly used text or special characters. An entity declaration may define either an internal or external entity. 

	For internal entities, the content of the entity is given in the declaration. 
	For external entities, the content is specified by a Uniform Resource Identifier (URI). 

Entities may be either parsed or unparsed. 

	The contents of a parsed entity are called its replacement text. 

	An unparsed entity is a resource whose contents may or may not be text, and if text, may be other than XML. Parsed entities are invoked by name using an entity reference; unparsed entities are invoked by name.

According to XML W3C Recommendation, section 4.4.3, "Included If Validating" [W3C 2008]:


When an XML processor recognizes a reference to a parsed entity, to validate the document, the processor MUST include its replacement text. 

	If the entity is external, and the processor is not attempting to validate the XML document, the processor MAY, but need not, include the entity's replacement text.

	Because inclusion of replacement text from an external entity is optional, not all XML processors are vulnerable to external entity attacks during validation.


An XML external entity (XXE) attack occurs when XML input containing a reference to an external entity is processed by an improperly configured XML parser. 

	An attacker might use an XXE attack to gain access to sensitive information by manipulating the URI of the entity to refer to files on the local file system containing sensitive data such as passwords and private user data. 

		An attacker might launch a denial-of-service attack, for example, by specifying /dev/random or /dev/tty as input URIs, which can crash or indefinitely block a program.
__________________________________________________________

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
 
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
 
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
 
class XXE {
  private static void receiveXMLStream(InputStream inStream,
                                       DefaultHandler defaultHandler)
      throws ParserConfigurationException, SAXException, IOException {
    SAXParserFactory factory = SAXParserFactory.newInstance();
    SAXParser saxParser = factory.newSAXParser();
    
    saxParser.parse(inStream, defaultHandler);
  }
 
  public static void main(String[] args) throws ParserConfigurationException,
      SAXException, IOException {
    try {
      receiveXMLStream(new FileInputStream("evil.xml"), new DefaultHandler());
    } catch (java.net.MalformedURLException mue) {
      System.err.println("Malformed URL Exception: " + mue);
    }
  }
}

// evil.xml
<?xml version="1.0"?>
<!DOCTYPE foo SYSTEM "file:/dev/tty">
<foo>bar</foo>

import java.io.IOException;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
 
class CustomResolver implements EntityResolver {
  public InputSource resolveEntity(String publicId, String systemId)
      throws SAXException, IOException {

	// WhiteList Entities 
    // Check for known good entities
    String entityPath = "file:/Users/onlinestore/good.xml";

    if (systemId.equals(entityPath)) {
      System.out.println("Resolving entity: " + publicId + " " + systemId);
      return new InputSource(entityPath);
    } else {
      // Disallow unknown entities by returning a blank path
      return new InputSource();
    }
  }
}

_____________________________________________________________________
Do not ignore values returned by methods
_____________________________________________________________________

// BAD CODE
public void deleteFile(){
 
  File someFile = new File("someFileName.txt");
  // Do something with someFile
  someFile.delete();
 
}

// GOOD CODE
public void deleteFile(){
 
  File someFile = new File("someFileName.txt");
  // Do something with someFile
  if (!someFile.delete()) {
    // Handle failure to delete the file
  }
}

// BAD CODE
public class Replace {
  public static void main(String[] args) {
    String original = "insecure";

    original.replace('i', '9');
    System.out.println(original);
  }
}

// GOOD CODE
public class Replace {
  public static void main(String[] args) {
    String original = "insecure";
    original = original.replace('i', '9');
    System.out.println(original);
  }
}

_____________________________________________________________________
Do not use a null in a case where an object is required
_____________________________________________________________________
Do not use the null value in any instance where an object is required, including the following cases:

	Calling the instance method of a null object
	Accessing or modifying the field of a null object
	Taking the length of null as if it were an array
	Accessing or modifying the elements of null as if it were an array
	Throwing null as if it were a Throwable value

// BAD CODE
public static int cardinality(Object obj, final Collection<?> col) {
  int count = 0;
  if (col == null) {
    return count;
  }

  Iterator<?> it = col.iterator();
  while (it.hasNext()) {
    Object elt = it.next();
    if ((null == obj && null == elt) || obj.equals(elt)) {  // Null pointer dereference
      count++;
    }
  }
  return count;
}

// GOOD CODE
public static int cardinality(Object obj, final Collection col) {
  int count = 0;
  if (col == null) {
    return count;
  }
  Iterator it = col.iterator();
  while (it.hasNext()) {
    Object elt = it.next();
    if ((null == obj && null == elt) ||
        (null != obj && obj.equals(elt))) {
      count++;
    }
  }
  return count;
}

//BAD CODE
public boolean isProperName(String s) {
  
  String names[] = s.split(" ");
  if (names.length != 2) {
    return false;
  }
  return (isCapitalized(names[0]) && isCapitalized(names[1]));
}

//WRAPPTER METHODS
public class Foo {
  private boolean isProperName(String s) {
    String names[] = s.split(" ");
    if (names.length != 2) {
      return false;
    }
    return (isCapitalized(names[0]) && isCapitalized(names[1]));
  }
 
  public boolean testString(String s) {
    if (s == null) return false;
    else return isProperName(s);
  }
}

// Optional Types
public boolean isProperName(Optional<String> os) {
  String names[] = os.orElse("").split(" ");
  return (names.length != 2) ? false :
         (isCapitalized(names[0]) && isCapitalized(names[1]));
}


_____________________________________________________________________
Do not use the Object.equals() method to compare two arrays
_____________________________________________________________________

// BAD CODE
int[] arr1 = new int[20]; // Initialized to 0
int[] arr2 = new int[20]; // Initialized to 0
System.out.println(arr1.equals(arr2)); // Object.equals()

// GOOD CODE
int[] arr1 = new int[20]; // Initialized to 0
int[] arr2 = new int[20]; // Initialized to 0
System.out.println(Arrays.equals(arr1, arr2)); // Prints true

_____________________________________________________________________
Do not use the equality operators when comparing values of boxed primitives
_____________________________________________________________________

// BAD CODE
import java.util.Comparator;
  
static Comparator<Integer> cmp = new Comparator<Integer>() {
  public int compare(Integer i, Integer j) {
    return i < j ? -1 : (i == j ? 0 : 1);
  }
};

The compare() method accepts two boxed primitives as arguments. The == operator is used to compare the two boxed primitives. In this context, however, it compares the references to the wrapper objects rather than comparing the values held in those objects.

// GOOD CODE
import java.util.Comparator;
  
static Comparator<Integer> cmp = new Comparator<Integer>() {
  public int compare(Integer i, Integer j) {
    return i < j ? -1 : (i > j ? 1 : 0) ;
  }
};

This compliant solution uses the comparison operators, <, >, <=, or >=, because these cause automatic unboxing of the primitive values. The == and != operators should not be used to compare boxed primitives.
_____________________________________________________________________

Do not pass arguments to certain Java Collections Framework methods that are a different type than the collection parameter type
_____________________________________________________________________

// BAD CODE
import java.util.HashSet;
  
public class ShortSet {
  public static void main(String[] args) {
    HashSet<Short> s = new HashSet<Short>();
    for (int i = 0; i < 10; i++) {
      s.add((short)i); // Cast required so that the code compiles
      
      s.remove(i); // Tries to remove an Integer

    }
    System.out.println(s.size());
  }
}

// GOOD CODE
import java.util.HashSet;
  
public class ShortSet {
  public static void main(String[] args) {
    HashSet<Short> s = new HashSet<Short>();
    for (int i = 0; i < 10; i++) {
      s.add((short)i);
      // Remove a Short
      if (s.remove((short)i) == false) {
        System.err.println("Error removing " + i);
      }
    }
    System.out.println(s.size());
  }
}

_____________________________________________________________________
Do not follow a write by a subsequent write or read of the same object within an expression
_____________________________________________________________________


According to The Java Language Specification (JLS), §15.7, "Evaluation Order" [JLS 2015]:

	The Java programming language guarantees that the operands of operators appear to be evaluated in a specific evaluation order, namely, from left to right.

§15.7.3, "Evaluation Respects Parentheses and Precedence" adds:

	Java programming language implementations must respect the order of evaluation as indicated explicitly by parentheses and implicitly by operator precedence.

// BAD CODE
class BadPrecedence {
  public static void main(String[] args) {
    int number = 17;
    int threshold = 10;
    
    // BAD PROGRAMMING PRACTICES
    number = (number > threshold ? 0 : -2)
             + (mutlipleValue * (number = get()));
    // ...
    if (number == 0) {
      System.out.println("Access granted");
    } else {
      System.out.println("Denied access"); // number = -2
    }
  }
 
  public static int get() {
    int number = 0;
    // Assign number to nonzero value if authorized, else 0
    return number;
  }
}

_____________________________________________________________________
Expressions used in assertions must not produce side effects
_____________________________________________________________________

private ArrayList<String> names;
 
void process(int index) {
  assert names.remove(null); // Side effect
  // ...
}

This noncompliant code attempts to delete all the null names from the list in an assertion. However, the Boolean expression is not evaluated when assertions are disabled.

The possibility of side effects in assertions can be avoided by decoupling the Boolean expression from the assertion:

private ArrayList<String> names;
 
void process(int index) {
  boolean nullsRemoved = names.remove(null);
  assert nullsRemoved; // No side effect
  // ...
}

_____________________________________________________________________
Limit accessibility of fields
_____________________________________________________________________
//BAD CODE
public class Widget {
  public int total; // Number of elements
 
  void add() {
    if (total < Integer.MAX_VALUE) {     
      total++;
      // ...
    } else {
      throw new ArithmeticException("Overflow");
    }
  }
 
  void remove() { 
    if (total > 0) {     
      total--;
      // ...
    } else {
      throw new ArithmeticException("Overflow");
    }
  }
}

// GOOD CODE
public class Widget {
  private int total; // Declared private
 
  public int getTotal () {
    return total;
  }
 
  // Definitions for add() and remove() remain the same
}

_____________________________________________________________________
SECURITY DESIGN PRINCIPLE
	DESIGN TOWARDS NARROW SCOPE|VISIBILTY|ACCESSIBILTY|PRIVILAGES ETC.
_____________________________________________________________________


_____________________________________________________________________
Preserve dependencies in subclasses when changing superclasses
_____________________________________________________________________

class Account {
  // Maintains all banking-related data such as account balance
  private double balance = 100;
  boolean withdraw(double amount) {
    if ((balance - amount) >= 0) {
      balance -= amount;
      System.out.println("Withdrawal successful. The balance is : "
                         + balance);
      return true;
    }
    return false;
  }

  boolean overdraft() {
    balance += 300;     // Add 300 in case there is an overdraft
    System.out.println("Added back-up amount. The balance is :"
                       + balance);
    return true;
  }
}
 
public class BankAccount extends Account {
  // Subclass handles authentication

  @Override boolean withdraw(double amount) {
    if (!securityCheck()) {
      throw new IllegalAccessException();
    }
    return super.withdraw(amount);
  }
 
  private final boolean securityCheck() {
    // Check that account management may proceed
  }

  @Override boolean overdraft() { // Override
    throw new IllegalAccessException();
  }
}
 
public class Client {
  public static void main(String[] args) {
    Account account = new BankAccount();
    // Enforce security manager check
    boolean result = account.withdraw(200.0);  
    System.out.println("Withdrawal successful? " + result);
  }
}

public class MaliciousClient {
  public static void main(String[] args) {
    Account account = new BankAccount();
    // No security check performed
    boolean result = account.overdraft();
    System.out.println("Withdrawal successful? " + result);
  }
}

_____________________________________________________________________
Prevent heap pollution
_____________________________________________________________________
// BAD CODE
class ListUtility {
  private static void addToList(List list, Object obj) {
    list.add(obj); // Unchecked warning
  }
 
  public static void main(String[] args) {
    List<String> list = new ArrayList<String> ();
    addToList(list, 42);
    System.out.println(list.get(0));  // Throws ClassCastException
  }
}

Heap pollution is possible in this case because the parameterized type information is discarded before execution. The call to addToList(list, 42) succeeds in adding an integer to list, although it is of type List<String>. This Java runtime does not throw a ClassCastException until the value is read and has an invalid type (an int rather than a String). In other words, the code throws an exception some time after the execution of the operation that actually caused the error, complicating debugging.


Even when heap pollution occurs, the variable is still guaranteed to refer to a subclass or subinterface of the declared type but is not guaranteed to always refer to a subtype of its declared type. In this example, list does not refer to a subtype of its declared type (List<String>) but only to the subinterface of the declared type (List).

// GOOD CODE
class ListUtility {
  private static void addToList(List<String> list, String str) {
    list.add(str);     // No warning generated
  }
 
  public static void main(String[] args) {
    List<String> list = new ArrayList<String> ();
    addToList(list, "42");
    System.out.println(list.get(0));
  }
}

_____________________________________________________________________
SECURITY DESIGN PRINCIPLE
	NEVER EVER MESS WITH DATA TYPE
		- BE EXPLICIT ABOUT DATA TYPE
		- CONSISTENCY IN TYPE ARGUMENTS AND COLLECTIONS
_____________________________________________________________________

_____________________________________________________________________
Provide mutable classes with copy functionality to safely allow passing instances to untrusted code
_____________________________________________________________________


public final class MutableClass {
  private Date date;
 
  public MutableClass(Date d) {
    this.date = d;
  }
 
  public void setDate(Date d) {
    this.date = d;
  }
 
  public Date getDate() {
    return date;
  }
}

// COPY CONSTRUCTOR
public final class MutableClass { // Copy constructor
  private final Date date;
 
  public MutableClass(MutableClass mc)  {
    this.date = new Date(mc.date.getTime());
  }
 
  public MutableClass(Date d) {
    this.date = new Date(d.getTime());  // Make defensive copy
  }
 
  public Date getDate() {
    return (Date) date.clone(); // Copy and return
  }
}

//FACTORY METHOD
class MutableClass {
  private final Date date;
 
  private MutableClass(Date d) { // Noninstantiable and nonsubclassable
    this.date = new Date(d.getTime());  // Make defensive copy
  }
 
  public Date getDate() {
    return (Date) date.clone(); // Copy and return
  }
 
  public static MutableClass getInstance(MutableClass mc)  {
    return new MutableClass(mc.getDate());
  }
}

// GOOD CODE
public final class MutableClass implements Cloneable {
  private Date date;
 
  public MutableClass(Date d) {
    this.date = new Date(d.getTime());
  }
 
  public Date getDate() {
    return (Date) date.clone();
  }
 
  public void setDate(Date d) {
    this.date = (Date) d.clone();
  }
 
  public Object clone() throws CloneNotSupportedException {
    final MutableClass cloned = (MutableClass) super.clone();
    cloned.date = (Date) date.clone();  // Manually copy mutable Date object
    return cloned;
  }
}

// CLONE WITH FINAL MEMBERS
public final class MutableClass implements Cloneable {
  private final Date date; // final field
 
  public MutableClass(Date d) {
    this.date = new Date(d.getTime());  // Copy in
  }
 
  public Date getDate() {
    return (Date) date.clone(); // Copy and return
  }
 
  public Object clone() {
    Date d = (Date) date.clone();
    MutableClass cloned = new MutableClass(d);
    return cloned;
  }
}

_____________________________________________________________________
SECURITY DESIGN PRINCIPLE
	NEVER PROVIDE REFERENCE TO OBJECTS FROM TRUSTED SYSTEM TO UNTRUSTED SYSTEMS
	NEVER PROVIDE REFERENCE TO OBJECTS FROM TRUSTED CODE TO EXTERNAL CODE/LIBRARIES etc.
_____________________________________________________________________


_____________________________________________________________________
Do not return references to private mutable class members
_____________________________________________________________________

// BAD CODE
class MutableClass {
  private Date d;
 
  public MutableClass() {
    d = new Date();
  }
 
  public Date getDate() {
    return d;
  }
}

// GOOD CODE
public Date getDate() {
  return (Date)d.clone();
}


_____________________________________________________________________
Sensitive classes must not let themselves be copied
_____________________________________________________________________


_____________________________________________________________________
Do not expose private members of an outer class from within a nested class
_____________________________________________________________________

__________________________________________________________
// BAD CODE
class Coordinates {
  private int x;
  private int y;
 
  public class Point {
    public void getPoint() {
      System.out.println("(" + x + "," + y + ")");
    }
  } 
}
 
class AnotherClass {
  public static void main(String[] args) {
    Coordinates c = new Coordinates();
    Coordinates.Point p = c.new Point();
    p.getPoint();
  }
}

// GOOD CODE
class Coordinates {
  private int x;
  private int y;
 
  private class Point { // Nested Class Made Private
    private void getPoint() {
      System.out.println("(" + x + "," + y + ")");
    }
  }
}
 
class AnotherClass {
  public static void main(String[] args) {
    Coordinates c = new Coordinates();
    Coordinates.Point p = c.new Point();    // Fails to compile
    p.getPoint();
  }
}

_____________________________________________________________________
Compare classes and not class names
_____________________________________________________________________

//BAD CODE
// Determine whether object auth has required/expected class object
if (auth.getClass().getName().equals(
      "com.application.auth.DefaultAuthenticationHandler")) {
   // ...
}

//GOOD CODE
// Determine whether object auth has required/expected class name
if (auth.getClass() == com.application.auth.DefaultAuthenticationHandler.class) {
   // ...
}

Comparing fully qualified class names is insufficient because distinct class loaders can load differing classes with identical fully qualified names into a single JVM.

//BAD CODE
// Determine whether objects x and y have the same class name
if (x.getClass().getName().equals(y.getClass().getName())) {
  // Objects have the same class
}

//GOOD CODE
// Determine whether objects x and y have the same class
if (x.getClass() == y.getClass()) {
  // Objects have the same class
}

_____________________________________________________________________
Best Practices For Implementing equals() method in Your Classes
_____________________________________________________________________

public boolean equals​(Object obj)
	Indicates whether some other object is "equal to" this one.

	The equals method implements an equivalence relation on non-null object references:

		It is reflexive: for any non-null reference value x, x.equals(x) should return true.

		It is symmetric: for any non-null reference values x and y, x.equals(y) should return true if and only if y.equals(x) returns true.

		It is transitive: for any non-null reference values x, y, and z, if x.equals(y) returns true and y.equals(z) returns true, then x.equals(z) should return true.

		It is consistent: for any non-null reference values x and y, multiple invocations of x.equals(y) consistently return true or consistently return false, provided no information used in equals comparisons on the objects is modified.

	For any non-null reference value x, x.equals(null) should return false.
	The equals method for class Object implements the most discriminating possible equivalence relation on objects; that is, for any non-null reference values x and y, this method returns true if and only if x and y refer to the same object (x == y has the value true).

	Note that it is generally necessary to override the hashCode method whenever this method is overridden, so as to maintain the general contract for the hashCode method, which states that equal objects must have equal hash codes.

hashCode() Contract
	Java SE also defines a contract for the hashCode() method. A thorough look at it shows how closely related hashCode() and equals() are.

	All three criteria in the contract of hashCode() mention in some ways the equals() method:

	internal consistency: the value of hashCode() may only change if a property that is in equals() changes
	equals consistency: objects that are equal to each other must return the same hashCode
	collisions: unequal objects may have the same hashCode


class Money {
    int amount;
    String currencyCode;

    @Override
	public boolean equals(Object o) {
	    if (o == this)
	        return true;
	    if (!(o instanceof Money))
	        return false;
	    Money other = (Money)o;
	    boolean currencyCodeEquals = (this.currencyCode == null && other.currencyCode == null)
	      || (this.currencyCode != null && this.currencyCode.equals(other.currencyCode));
	    return this.amount == other.amount && currencyCodeEquals;
	}

	@Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + amount;
        if (currencyCode != null) {
            result = 31 * result + currencyCode.hashCode();
        }
        return result;
    }
}

Money income = new Money(55, "USD");  	// Fully Created
Money expenses = new Money(55, "USD");  
boolean balanced = income.equals(expenses)


class WrongVoucher extends Money { 
    private String store;
 
    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof WrongVoucher))
            return false;
        WrongVoucher other = (WrongVoucher)o;
        boolean currencyCodeEquals = (this.currencyCode == null && other.currencyCode == null)
          || (this.currencyCode != null && this.currencyCode.equals(other.currencyCode));
        boolean storeEquals = (this.store == null && other.store == null)
          || (this.store != null && this.store.equals(other.store));
        return this.amount == other.amount && currencyCodeEquals && storeEquals;
    }
 
    // other methods
}

Money cash = new Money(42, "USD");
WrongVoucher voucher = new WrongVoucher(42, "USD", "Amazon");
 
voucher.equals(cash)  // => false // As expected.
cash.equals(voucher)  // => true  // Wrong Result

__________________________________________________________
// GOOD CODE
class Voucher {
 
    private Money value;
    private String store;
 
    Voucher(int amount, String currencyCode, String store) {
        this.value = new Money(amount, currencyCode);
        this.store = store;
    }
 
    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Voucher))
            return false;
        Voucher other = (Voucher) o;
        boolean valueEquals = (this.value == null && other.value == null)
          || (this.value != null && this.value.equals(other.value));
        boolean storeEquals = (this.store == null && other.store == null)
          || (this.store != null && this.store.equals(other.store));
        return valueEquals && storeEquals;
    }
 
    // other methods
}















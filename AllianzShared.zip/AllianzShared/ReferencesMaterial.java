
+++++++++++++++++++++++++++++++++++++++++++++++++++
	PLEASE STAY THERE!
	DONT GO AWAY AFTER COMPELTING FEEDBACK!
++++++++++++++++++++++++++++++++++++++++++++++++++


Reference Materials
_______________________________________________________________

CERT Secure Coding Guidelines
	https://wiki.sei.cmu.edu/confluence/display/java/SEI+CERT+Oracle+Coding+Standard+for+Java

Java Language Specifications
	https://docs.oracle.com/en/java/javase/11/docs/api/index.html


Discussion Notes and Study Material
_______________________________________________________________

